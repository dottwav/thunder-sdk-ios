//
//  LinkGeneratorViewController.swift
//  AdTonosLinkGeneratorSampleApp
//
//  Created by Mateusz Wojnar on 10/12/2021.
//

import UIKit
import AdTonosLinkGenerator

class LinkGeneratorViewController: UIViewController {

    @IBOutlet weak var vastLinkLabel: UILabel!

    private let adTonos = AdTonosSDK.shared

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func generateLink(_ sender: Any) {
        //Creates an empty builder instance for further usage.
        let builder = adTonos.createBuilder()


        guard let vastLink = try? builder
                .set(adTonosKey: "KT267qyGPudAugiSt") //Sets developer key.
                .set(lang: "en") //Sets user language if different than a system defined
                .build() //Builds url for obtaining advertisements from VAST compliant advertisements provider.
        else { return }

        print(vastLink)
        vastLinkLabel.text = vastLink
    }
}
